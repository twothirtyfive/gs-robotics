from gopigo import *

from control import *

import time 
  
fwd()
time.sleep(1)
stop()
bwd()
time.sleep(1)
stop()
left()
time.sleep(1)
stop()
right()
time.sleep(1)
stop()



	
















